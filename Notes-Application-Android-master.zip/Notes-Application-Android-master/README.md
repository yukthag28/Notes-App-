<h1>Notes-Application-Android</h1>
<ul>
<li>A Light Weight Notes Application for Android SmartPhones.</li>
<li>You can now save, Modify and Delete your notes.</li>
<li>It uses SQLite Database for Storing and Uses Room Persistence Library for Saving.</li>
<li>AsyncTask is Used to reduce the Load on main Thread and Prevent App from Creashing.</li>
</ul>

# Features
<ul>
<li>Simplistic UI.</li>
<li>Easy to use interface </li>
<li>Swipe to delete operation</li>
<li>Easy addition,deletion of note</li>
<li>Easy editing</li>
</ul>

# Contribute
If you think app needs some improvement feel free to leave the suggestions or contribute to this Project.


# Screenshots of Project
<img src="https://github.com/l33t-c0d3r-66/Notes-Application-Android/blob/master/app/src/main/res/ProjectImages/1.jpeg"  width="400" height="600">&emsp;<img src="https://github.com/l33t-c0d3r-66/Notes-Application-Android/blob/master/app/src/main/res/ProjectImages/2.jpeg"  width="400" height="600">

<img src="https://github.com/l33t-c0d3r-66/Notes-Application-Android/blob/master/app/src/main/res/ProjectImages/3.jpeg"  width="400" height="600">&emsp;<img src="https://github.com/l33t-c0d3r-66/Notes-Application-Android/blob/master/app/src/main/res/ProjectImages/4.jpeg"  width="400" height="600">
